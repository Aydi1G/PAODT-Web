function hideI(){
document.getElementById("crlAdmin").style.display="none";
    document.getElementById("crlDonor").style.display="none";
    document.getElementById("crlDoctor").style.display="none";
    document.getElementById("crlRecipient").style.display="none";

}
let h=0
function showLabels1(){
    document.getElementById("crlAdmin").style.display="inline-block";

}
function hideLabels1(){
    document.getElementById("crlAdmin").style.display="none";

}
function showLabels2(){
    document.getElementById("crlDoctor").style.display="inline-block";

}
function hideLabels2(){
    document.getElementById("crlDoctor").style.display="none";

}
function showLabels3(){
    document.getElementById("crlDonor").style.display="inline-block";

}
function hideLabels3(){
    document.getElementById("crlDonor").style.display="none";

}
function showLabels4(){
    document.getElementById("crlRecipient").style.display="inline-block";

}
function hideLabels4(){
    document.getElementById("crlRecipient").style.display="none";

}